#ifndef XMP_PLATFORM_H
#define XMP_PLATFORM_H

FILE *make_temp_file(char **);
void unlink_temp_file(char *);

#endif
